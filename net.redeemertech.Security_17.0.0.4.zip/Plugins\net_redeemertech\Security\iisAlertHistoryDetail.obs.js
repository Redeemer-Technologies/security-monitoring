System.register(['vue', '@Obsidian/Controls/grid', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/panel.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var createElementVNode, defineComponent, ref, computed, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, Fragment, renderList, createCommentVNode, Grid, TextColumn, textValueFilter, NotificationBox, Panel, AlertType, useConfigurationValues;
  return {
    setters: [function (module) {
      createElementVNode = module.createElementVNode;
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      Fragment = module.Fragment;
      renderList = module.renderList;
      createCommentVNode = module.createCommentVNode;
    }, function (module) {
      Grid = module["default"];
      TextColumn = module.TextColumn;
      textValueFilter = module.textValueFilter;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      Panel = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
    }],
    execute: (function () {

      var _hoisted_1 = {
        class: "dl-horizontal"
      };
      var _hoisted_2 = createElementVNode("dt", null, "Tripped", -1);
      var _hoisted_3 = createElementVNode("dt", null, "Result Count", -1);
      var _hoisted_4 = createElementVNode("dt", null, "Summary", -1);
      var script = exports('default', defineComponent({
        __name: 'iisAlertHistoryDetail',
        setup(__props) {
          var _config$history, _config$errorMessage;
          var config = useConfigurationValues();
          var history = ref((_config$history = config.history) !== null && _config$history !== void 0 ? _config$history : null);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var rows = computed(() => {
            var _history$value$result, _history$value;
            return parseRows((_history$value$result = (_history$value = history.value) === null || _history$value === void 0 ? void 0 : _history$value.resultJson) !== null && _history$value$result !== void 0 ? _history$value$result : "");
          });
          var columns = computed(() => rows.value.length ? Object.keys(rows.value[0]) : []);
          var gridDataSource = computed(() => Promise.resolve({
            rows: rows.value
          }));
          function parseRows(json) {
            if (!json) {
              return [];
            }
            try {
              var parsed = JSON.parse(json);
              if (!Array.isArray(parsed)) {
                return [];
              }
              return parsed.map((row, index) => {
                var values = {
                  uniqueKey: String(index)
                };
                if (row && typeof row === "object" && !Array.isArray(row)) {
                  Object.keys(row).forEach(key => {
                    var value = row[key];
                    values[key] = value === null || value === undefined ? "" : String(value);
                  });
                }
                return values;
              });
            } catch (_unused) {
              return [];
            }
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : history.value ? (openBlock(), createBlock(unref(Panel), {
              key: 1,
              title: history.value.alertName || 'IIS Alert History'
            }, {
              default: withCtx(() => [createElementVNode("dl", _hoisted_1, [_hoisted_2, createElementVNode("dd", null, toDisplayString(history.value.trippedDateTime), 1), _hoisted_3, createElementVNode("dd", null, toDisplayString(history.value.resultCount), 1), _hoisted_4, createElementVNode("dd", null, toDisplayString(history.value.summary || ''), 1)]), columns.value.length ? (openBlock(), createBlock(unref(Grid), {
                key: 0,
                title: "Results",
                data: gridDataSource.value,
                keyField: "uniqueKey",
                itemTerm: "Result",
                stickyHeader: ""
              }, {
                default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(columns.value, column => {
                  return openBlock(), createBlock(unref(TextColumn), {
                    key: column,
                    name: column,
                    title: column,
                    field: column,
                    filter: unref(textValueFilter),
                    visiblePriority: "xs"
                  }, null, 8, ["name", "title", "field", "filter"]);
                }), 128))]),
                _: 1
              }, 8, ["data"])) : (openBlock(), createBlock(unref(NotificationBox), {
                key: 1,
                alertType: unref(AlertType).Info
              }, {
                default: withCtx(() => [createTextVNode("No result rows were saved.")]),
                _: 1
              }, 8, ["alertType"]))]),
              _: 1
            }, 8, ["title"])) : createCommentVNode("v-if", true)]);
          };
        }
      }));

      script.__file = "src/iisAlertHistoryDetail.obs";

    })
  };
}));
//# sourceMappingURL=iisAlertHistoryDetail.obs.js.map
