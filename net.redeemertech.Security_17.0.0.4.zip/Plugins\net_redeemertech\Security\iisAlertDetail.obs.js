System.register(['vue', '@Obsidian/Controls/checkBox.obs', '@Obsidian/Controls/codeEditor.obs', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/numberBox.obs', '@Obsidian/Controls/panel.obs', '@Obsidian/Controls/rockButton.obs', '@Obsidian/Controls/slidingDateRangePicker.obs', '@Obsidian/Controls/textBox.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var createElementVNode, defineComponent, ref, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, Fragment, createCommentVNode, createVNode, CheckBox, CodeEditor, NotificationBox, NumberBox, Panel, RockButton, SlidingDateRangePicker, TextBox, AlertType, useConfigurationValues, useInvokeBlockAction;
  return {
    setters: [function (module) {
      createElementVNode = module.createElementVNode;
      defineComponent = module.defineComponent;
      ref = module.ref;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      Fragment = module.Fragment;
      createCommentVNode = module.createCommentVNode;
      createVNode = module.createVNode;
    }, function (module) {
      CheckBox = module["default"];
    }, function (module) {
      CodeEditor = module["default"];
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      NumberBox = module["default"];
    }, function (module) {
      Panel = module["default"];
    }, function (module) {
      RockButton = module["default"];
    }, function (module) {
      SlidingDateRangePicker = module["default"];
    }, function (module) {
      TextBox = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
    }],
    execute: (function () {

      function ownKeys(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          r && (o = o.filter(function (r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
          })), t.push.apply(t, o);
        }
        return t;
      }
      function _objectSpread2(e) {
        for (var r = 1; r < arguments.length; r++) {
          var t = null != arguments[r] ? arguments[r] : {};
          r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
            _defineProperty(e, r, t[r]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
          });
        }
        return e;
      }
      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }
      function _defineProperty(obj, key, value) {
        key = _toPropertyKey(key);
        if (key in obj) {
          Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      function _toPrimitive(input, hint) {
        if (typeof input !== "object" || input === null) return input;
        var prim = input[Symbol.toPrimitive];
        if (prim !== undefined) {
          var res = prim.call(input, hint || "default");
          if (typeof res !== "object") return res;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return (hint === "string" ? String : Number)(input);
      }
      function _toPropertyKey(arg) {
        var key = _toPrimitive(arg, "string");
        return typeof key === "symbol" ? key : String(key);
      }

      var _hoisted_1 = {
        class: "dl-horizontal"
      };
      var _hoisted_2 = createElementVNode("dt", null, "Description", -1);
      var _hoisted_3 = createElementVNode("dt", null, "Active", -1);
      var _hoisted_4 = createElementVNode("dt", null, "Email Addresses", -1);
      var _hoisted_5 = createElementVNode("dt", null, "Evaluate Every", -1);
      var _hoisted_6 = createElementVNode("dt", null, "Block IP Addresses", -1);
      var _hoisted_7 = createElementVNode("dt", null, "Lock Out User Accounts", -1);
      var _hoisted_8 = createElementVNode("dt", null, "Last Run", -1);
      var _hoisted_9 = createElementVNode("h4", null, "Query", -1);
      var _hoisted_10 = {
        class: "well well-sm"
      };
      var _hoisted_11 = createElementVNode("h4", null, "Summary Lava", -1);
      var _hoisted_12 = {
        class: "well well-sm"
      };
      var _hoisted_13 = createElementVNode("h4", null, "Query", -1);
      var _hoisted_14 = createElementVNode("h4", null, "Summary", -1);
      var _hoisted_15 = createElementVNode("h4", null, "Notification", -1);
      var _hoisted_16 = createElementVNode("h4", null, "Response Actions", -1);
      var alertPageParameter = "IISAlertId";
      var script = exports('default', defineComponent({
        __name: 'iisAlertDetail',
        setup(__props) {
          var _config$errorMessage;
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          var alert = ref(config.alert || {
            isActive: true,
            evaluationFrequencyMinutes: 60,
            dateRange: config.defaultDateRange,
            blockIpAddress: false,
            blockIpAddressMinutes: 60,
            lockOutUserAccounts: false
          });
          var savedAlert = ref(alert.value.idKey ? _objectSpread2({}, alert.value) : null);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var isEditable = config.isEditable;
          var isEditMode = ref(isEditable && !alert.value.idKey);
          var isSaving = ref(false);
          function edit() {
            isEditMode.value = true;
          }
          function cancel() {
            if (savedAlert.value) {
              alert.value = _objectSpread2({}, savedAlert.value);
              isEditMode.value = false;
            }
          }
          function save() {
            return _save.apply(this, arguments);
          }
          function _save() {
            _save = _asyncToGenerator(function* () {
              var isNewAlert = !alert.value.idKey;
              isSaving.value = true;
              var result = yield invokeBlockAction("SaveAlert", {
                bag: alert.value
              });
              isSaving.value = false;
              if (result.isSuccess && result.data) {
                alert.value = result.data;
                savedAlert.value = _objectSpread2({}, result.data);
                isEditMode.value = false;
                if (isNewAlert && result.data.idKey) {
                  updateUrlForSavedAlert(result.data.idKey);
                }
              } else {
                errorMessage.value = result.errorMessage || "Unable to save alert.";
              }
            });
            return _save.apply(this, arguments);
          }
          function updateUrlForSavedAlert(idKey) {
            var url = new URL(window.location.href);
            if (url.searchParams.has(alertPageParameter)) {
              url.searchParams.set(alertPageParameter, idKey);
            } else if (!replaceNewAlertPathSegment(url, idKey)) {
              url.searchParams.set(alertPageParameter, idKey);
            }
            window.history.replaceState(window.history.state, "", url.toString());
          }
          function replaceNewAlertPathSegment(url, idKey) {
            var segments = url.pathname.split("/");
            for (var i = segments.length - 1; i >= 0; i--) {
              if (decodeURIComponent(segments[i]) === "0") {
                segments[i] = encodeURIComponent(idKey);
                url.pathname = segments.join("/");
                return true;
              }
            }
            return false;
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : (openBlock(), createBlock(unref(Panel), {
              key: 1,
              title: alert.value.name || 'IIS Alert Detail'
            }, {
              default: withCtx(() => [!isEditMode.value ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [createElementVNode("dl", _hoisted_1, [_hoisted_2, createElementVNode("dd", null, toDisplayString(alert.value.description || ''), 1), _hoisted_3, createElementVNode("dd", null, toDisplayString(alert.value.isActive ? 'Yes' : 'No'), 1), _hoisted_4, createElementVNode("dd", null, toDisplayString(alert.value.notificationEmails || ''), 1), _hoisted_5, createElementVNode("dd", null, toDisplayString(alert.value.evaluationFrequencyMinutes) + " minute(s)", 1), _hoisted_6, createElementVNode("dd", null, toDisplayString(alert.value.blockIpAddress ? "Yes, for ".concat(alert.value.blockIpAddressMinutes || 60, " minute(s)") : 'No'), 1), _hoisted_7, createElementVNode("dd", null, toDisplayString(alert.value.lockOutUserAccounts ? 'Yes' : 'No'), 1), _hoisted_8, createElementVNode("dd", null, toDisplayString(alert.value.lastRunDateTime || 'Never'), 1)]), _hoisted_9, createElementVNode("pre", _hoisted_10, toDisplayString(alert.value.query), 1), _hoisted_11, createElementVNode("pre", _hoisted_12, toDisplayString(alert.value.summaryLava), 1), unref(isEditable) ? (openBlock(), createBlock(unref(RockButton), {
                key: 0,
                btnType: "primary",
                onClick: edit
              }, {
                default: withCtx(() => [createTextVNode("Edit")]),
                _: 1
              })) : createCommentVNode("v-if", true)], 64)) : (openBlock(), createElementBlock(Fragment, {
                key: 1
              }, [createVNode(unref(TextBox), {
                modelValue: alert.value.name,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => alert.value.name = $event),
                label: "Name"
              }, null, 8, ["modelValue"]), createVNode(unref(TextBox), {
                modelValue: alert.value.description,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => alert.value.description = $event),
                label: "Description",
                textMode: "multiline",
                rows: 3
              }, null, 8, ["modelValue"]), createVNode(unref(CheckBox), {
                modelValue: alert.value.isActive,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => alert.value.isActive = $event),
                label: "Active"
              }, null, 8, ["modelValue"]), _hoisted_13, createVNode(unref(CodeEditor), {
                modelValue: alert.value.query,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => alert.value.query = $event),
                label: "SQL Query",
                help: "Use [[logs]] in the FROM clause as the IIS log parquet source.",
                mode: "sql",
                rows: 12
              }, null, 8, ["modelValue"]), createVNode(unref(SlidingDateRangePicker), {
                modelValue: alert.value.dateRange,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => alert.value.dateRange = $event),
                label: "Date Range",
                help: "Only parquet files whose filename date stamp falls within this range will be included.",
                previewLocation: "Right"
              }, null, 8, ["modelValue"]), _hoisted_14, createVNode(unref(CodeEditor), {
                modelValue: alert.value.summaryLava,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => alert.value.summaryLava = $event),
                label: "Summary Lava",
                help: "Formats the alert history summary. The results merge field contains the query rows. Lava commands are disabled when this is resolved.",
                mode: "lava",
                rows: 8
              }, null, 8, ["modelValue"]), _hoisted_15, createVNode(unref(TextBox), {
                modelValue: alert.value.notificationEmails,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => alert.value.notificationEmails = $event),
                label: "Email Addresses",
                help: "Comma-separated list of email addresses to notify when this alert trips."
              }, null, 8, ["modelValue"]), createVNode(unref(NumberBox), {
                modelValue: alert.value.evaluationFrequencyMinutes,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => alert.value.evaluationFrequencyMinutes = $event),
                label: "Evaluate Every Minutes",
                minimumValue: 1
              }, null, 8, ["modelValue"]), _hoisted_16, createVNode(unref(CheckBox), {
                modelValue: alert.value.blockIpAddress,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => alert.value.blockIpAddress = $event),
                label: "Block IP Addresses",
                help: "When enabled, the alert query must return a BlockedIpAddress column. The c-ip column is also accepted."
              }, null, 8, ["modelValue"]), alert.value.blockIpAddress ? (openBlock(), createBlock(unref(NumberBox), {
                key: 0,
                modelValue: alert.value.blockIpAddressMinutes,
                "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => alert.value.blockIpAddressMinutes = $event),
                label: "Block IP for Minutes",
                minimumValue: 1
              }, null, 8, ["modelValue"])) : createCommentVNode("v-if", true), createVNode(unref(CheckBox), {
                modelValue: alert.value.lockOutUserAccounts,
                "onUpdate:modelValue": _cache[10] || (_cache[10] = $event => alert.value.lockOutUserAccounts = $event),
                label: "Lock Out User Accounts",
                help: "When enabled, the alert query must return a UserLoginId, UserName, or cs-username column."
              }, null, 8, ["modelValue"]), createVNode(unref(RockButton), {
                btnType: "primary",
                disabled: isSaving.value,
                onClick: save
              }, {
                default: withCtx(() => [createTextVNode("Save")]),
                _: 1
              }, 8, ["disabled"]), savedAlert.value ? (openBlock(), createBlock(unref(RockButton), {
                key: 1,
                disabled: isSaving.value,
                onClick: cancel
              }, {
                default: withCtx(() => [createTextVNode("Cancel")]),
                _: 1
              }, 8, ["disabled"])) : createCommentVNode("v-if", true)], 64))]),
              _: 1
            }, 8, ["title"]))]);
          };
        }
      }));

      script.__file = "src/iisAlertDetail.obs";

    })
  };
}));
//# sourceMappingURL=iisAlertDetail.obs.js.map
