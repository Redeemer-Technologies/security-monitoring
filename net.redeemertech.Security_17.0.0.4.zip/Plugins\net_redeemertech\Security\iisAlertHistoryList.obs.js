System.register(['vue', '@Obsidian/Controls/grid', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createVNode, Grid, TextColumn, textValueFilter, NumberColumn, NotificationBox, AlertType, useConfigurationValues;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createVNode = module.createVNode;
    }, function (module) {
      Grid = module["default"];
      TextColumn = module.TextColumn;
      textValueFilter = module.textValueFilter;
      NumberColumn = module.NumberColumn;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
    }],
    execute: (function () {

      var script = exports('default', defineComponent({
        __name: 'iisAlertHistoryList',
        setup(__props) {
          var _config$histories, _config$errorMessage;
          var config = useConfigurationValues();
          var histories = ref((_config$histories = config.histories) !== null && _config$histories !== void 0 ? _config$histories : []);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var gridDataSource = computed(() => Promise.resolve({
            rows: histories.value
          }));
          function goToHistory(idKey) {
            if (idKey) {
              window.location.href = (config.historyDetailPageUrl || "").replace("((IdKey))", encodeURIComponent(idKey));
            }
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : (openBlock(), createBlock(unref(Grid), {
              key: 1,
              title: "IIS Alert History",
              data: gridDataSource.value,
              keyField: "idKey",
              itemTerm: "IIS Alert History",
              tooltipField: "alertName",
              stickyHeader: "",
              onSelectItem: goToHistory
            }, {
              default: withCtx(() => [createVNode(unref(TextColumn), {
                name: "alertName",
                title: "Alert",
                field: "alertName",
                filter: unref(textValueFilter),
                width: "50%"
              }, null, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "trippedDateTime",
                title: "Tripped",
                field: "trippedDateTime",
                filter: unref(textValueFilter),
                visiblePriority: "sm",
                width: "30%"
              }, null, 8, ["filter"]), createVNode(unref(NumberColumn), {
                name: "resultCount",
                title: "Rows",
                field: "resultCount",
                visiblePriority: "xs",
                width: "20%"
              })]),
              _: 1
            }, 8, ["data"]))]);
          };
        }
      }));

      script.__file = "src/iisAlertHistoryList.obs";

    })
  };
}));
//# sourceMappingURL=iisAlertHistoryList.obs.js.map
