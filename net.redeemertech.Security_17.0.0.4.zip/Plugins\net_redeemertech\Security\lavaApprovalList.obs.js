System.register(['vue', '@Obsidian/Controls/grid', '@Obsidian/Controls/modal.obs', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/rockButton.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, onMounted, watch, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createCommentVNode, createVNode, createElementVNode, normalizeClass, withModifiers, Fragment, renderList, normalizeStyle, pushScopeId, popScopeId, Grid, SelectColumn, Column, textValueFilter, numberValueFilter, TextColumn, pickExistingValueFilter, Modal, NotificationBox, RockButton, AlertType, useConfigurationValues, useInvokeBlockAction, useReloadBlock;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      onMounted = module.onMounted;
      watch = module.watch;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createCommentVNode = module.createCommentVNode;
      createVNode = module.createVNode;
      createElementVNode = module.createElementVNode;
      normalizeClass = module.normalizeClass;
      withModifiers = module.withModifiers;
      Fragment = module.Fragment;
      renderList = module.renderList;
      normalizeStyle = module.normalizeStyle;
      pushScopeId = module.pushScopeId;
      popScopeId = module.popScopeId;
    }, function (module) {
      Grid = module["default"];
      SelectColumn = module.SelectColumn;
      Column = module.Column;
      textValueFilter = module.textValueFilter;
      numberValueFilter = module.numberValueFilter;
      TextColumn = module.TextColumn;
      pickExistingValueFilter = module.pickExistingValueFilter;
    }, function (module) {
      Modal = module["default"];
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      RockButton = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      useReloadBlock = module.useReloadBlock;
    }],
    execute: (function () {

      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }
      function _unsupportedIterableToArray(o, minLen) {
        if (!o) return;
        if (typeof o === "string") return _arrayLikeToArray(o, minLen);
        var n = Object.prototype.toString.call(o).slice(8, -1);
        if (n === "Object" && o.constructor) n = o.constructor.name;
        if (n === "Map" || n === "Set") return Array.from(o);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length) len = arr.length;
        for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
        return arr2;
      }
      function _createForOfIteratorHelper(o, allowArrayLike) {
        var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
        if (!it) {
          if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
            if (it) o = it;
            var i = 0;
            var F = function () {};
            return {
              s: F,
              n: function () {
                if (i >= o.length) return {
                  done: true
                };
                return {
                  done: false,
                  value: o[i++]
                };
              },
              e: function (e) {
                throw e;
              },
              f: F
            };
          }
          throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        var normalCompletion = true,
          didErr = false,
          err;
        return {
          s: function () {
            it = it.call(o);
          },
          n: function () {
            var step = it.next();
            normalCompletion = step.done;
            return step;
          },
          e: function (e) {
            didErr = true;
            err = e;
          },
          f: function () {
            try {
              if (!normalCompletion && it.return != null) it.return();
            } finally {
              if (didErr) throw err;
            }
          }
        };
      }

      var _withScopeId = n => (pushScopeId("data-v-5570eb54"), n = n(), popScopeId(), n);
      var _hoisted_1 = {
        class: "lava-preview"
      };
      var _hoisted_2 = {
        key: 0,
        class: "public-status"
      };
      var _hoisted_3 = {
        key: 1
      };
      var _hoisted_4 = {
        key: 2,
        class: "text-muted"
      };
      var _hoisted_5 = {
        key: 1,
        class: "text-muted"
      };
      var _hoisted_6 = _withScopeId(() => createElementVNode("dt", null, "Source", -1));
      var _hoisted_7 = _withScopeId(() => createElementVNode("dt", null, "Public", -1));
      var _hoisted_8 = _withScopeId(() => createElementVNode("dt", null, "Content Hash", -1));
      var _hoisted_9 = _withScopeId(() => createElementVNode("strong", null, "High Risk:", -1));
      var _hoisted_10 = _withScopeId(() => createElementVNode("strong", null, "Urgent Risk:", -1));
      var _hoisted_11 = _withScopeId(() => createElementVNode("strong", null, "AI Review:", -1));
      var _hoisted_12 = {
        key: 0
      };
      var _hoisted_13 = {
        key: 3,
        class: "source-table table-striped"
      };
      var _hoisted_14 = _withScopeId(() => createElementVNode("thead", null, [createElementVNode("tr", null, [createElementVNode("th", null, "Location"), createElementVNode("th", null, "Public"), createElementVNode("th", null, "Shortcode Risk"), createElementVNode("th", null, "Detected")])], -1));
      var _hoisted_15 = {
        key: 0,
        class: "entity-details"
      };
      var _hoisted_16 = ["href"];
      var _hoisted_17 = {
        key: 1
      };
      var _hoisted_18 = {
        key: 0,
        class: "public-status"
      };
      var _hoisted_19 = {
        key: 1
      };
      var _hoisted_20 = {
        key: 2,
        class: "text-muted"
      };
      var _hoisted_21 = {
        class: "approval-content"
      };
      var _hoisted_22 = {
        key: 0
      };
      var _hoisted_23 = {
        key: 1,
        class: "text-muted"
      };
      var _hoisted_24 = {
        class: "ai-review-progress"
      };
      var _hoisted_25 = {
        class: "progress"
      };
      var _hoisted_26 = {
        key: 0,
        class: "text-muted"
      };
      var _hoisted_27 = {
        key: 1,
        class: "ai-review-errors"
      };
      var aiReviewConcurrency = 10;
      var script = exports('default', defineComponent({
        __name: 'lavaApprovalList',
        setup(__props) {
          var _config$sources, _config$errorMessage;
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          var reloadBlock = useReloadBlock();
          var sources = ref((_config$sources = config.sources) !== null && _config$sources !== void 0 ? _config$sources : []);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var modalErrorMessage = ref("");
          var selectedContent = ref("");
          var selectedContentHash = ref("");
          var selectedSources = ref([]);
          var selectedSource = ref(null);
          var selectedAIReviewDetails = ref("");
          var selectedAIRiskAssessment = ref("");
          var selectedAIHasConcerns = ref(false);
          var selectedAIReviewDateTime = ref("");
          var isModalOpen = ref(false);
          var isAIReviewProgressOpen = ref(false);
          var isAIReviewInProgress = ref(false);
          var aiReviewCompletedCount = ref(0);
          var aiReviewTotalCount = ref(0);
          var aiReviewCurrentHash = ref("");
          var aiReviewProgressMessage = ref("");
          var aiReviewProgressError = ref("");
          var aiReviewErrors = ref([]);
          var isEditable = config.isEditable;
          var isAIReviewConfigured = config.isAIReviewConfigured;
          var gridDataSource = computed(() => Promise.resolve({
            rows: sources.value
          }));
          var aiReviewProgressPercent = computed(() => {
            if (!aiReviewTotalCount.value) {
              return 0;
            }
            return Math.round(aiReviewCompletedCount.value / aiReviewTotalCount.value * 100);
          });
          var gridActions = computed(() => {
            if (!isEditable) {
              return [];
            }
            var actions = [{
              title: "Approve",
              tooltip: "Approve selected Lava content",
              iconCssClass: "ti ti-check",
              handler: approveSelectedRows
            }];
            if (!isAIReviewConfigured) {
              return actions;
            }
            actions.push({
              title: "AI Review",
              tooltip: "Review selected Lava content with AI",
              iconCssClass: "ti ti-sparkles",
              disabled: isAIReviewInProgress.value,
              handler: reviewSelectedWithAI
            });
            return actions;
          });
          onMounted(() => {
            var hash = getUrlHashParameter();
            if (hash) {
              openApproval(hash);
            }
          });
          watch(isModalOpen, isOpen => {
            if (!isOpen) {
              setUrlHashParameter(null);
            }
          });
          function getUrlHashParameter() {
            var _URL$searchParams$get;
            return (_URL$searchParams$get = new URL(window.location.href).searchParams.get("hash")) !== null && _URL$searchParams$get !== void 0 ? _URL$searchParams$get : "";
          }
          function setUrlHashParameter(hash) {
            var url = new URL(window.location.href);
            if (hash) {
              url.searchParams.set("hash", hash);
            } else {
              url.searchParams.delete("hash");
            }
            window.history.replaceState(window.history.state, "", url);
          }
          function openApproval(_x) {
            return _openApproval.apply(this, arguments);
          }
          function _openApproval() {
            _openApproval = _asyncToGenerator(function* (idKey) {
              var _sources$value$find, _source$contentHash, _source$aiReviewDetai, _source$aiRiskAssessm, _source$aiReviewDateT, _source$contentHash2;
              var source = (_sources$value$find = sources.value.find(s => s.idKey === idKey)) !== null && _sources$value$find !== void 0 ? _sources$value$find : null;
              if (!idKey || !source) {
                return;
              }
              selectedSource.value = source;
              selectedContent.value = "";
              selectedContentHash.value = (_source$contentHash = source.contentHash) !== null && _source$contentHash !== void 0 ? _source$contentHash : "";
              selectedSources.value = [];
              selectedAIReviewDetails.value = (_source$aiReviewDetai = source.aiReviewDetails) !== null && _source$aiReviewDetai !== void 0 ? _source$aiReviewDetai : "";
              selectedAIRiskAssessment.value = (_source$aiRiskAssessm = source.aiRiskAssessment) !== null && _source$aiRiskAssessm !== void 0 ? _source$aiRiskAssessm : "";
              selectedAIHasConcerns.value = source.aiHasVulnerabilityConcerns === true;
              selectedAIReviewDateTime.value = (_source$aiReviewDateT = source.aiReviewDateTime) !== null && _source$aiReviewDateT !== void 0 ? _source$aiReviewDateT : "";
              modalErrorMessage.value = "";
              isModalOpen.value = true;
              setUrlHashParameter((_source$contentHash2 = source.contentHash) !== null && _source$contentHash2 !== void 0 ? _source$contentHash2 : idKey);
              var result = yield invokeBlockAction("GetSourceContent", {
                contentHash: source.contentHash
              });
              if (result.isSuccess && result.data) {
                var _data$content, _data$contentHash, _data$sources, _data$aiReviewDetails, _data$aiRiskAssessmen, _data$aiReviewDateTim;
                var data = result.data;
                selectedContent.value = (_data$content = data.content) !== null && _data$content !== void 0 ? _data$content : "";
                selectedContentHash.value = (_data$contentHash = data.contentHash) !== null && _data$contentHash !== void 0 ? _data$contentHash : selectedContentHash.value;
                selectedSources.value = (_data$sources = data.sources) !== null && _data$sources !== void 0 ? _data$sources : [];
                selectedAIReviewDetails.value = (_data$aiReviewDetails = data.aiReviewDetails) !== null && _data$aiReviewDetails !== void 0 ? _data$aiReviewDetails : selectedAIReviewDetails.value;
                selectedAIRiskAssessment.value = (_data$aiRiskAssessmen = data.aiRiskAssessment) !== null && _data$aiRiskAssessmen !== void 0 ? _data$aiRiskAssessmen : selectedAIRiskAssessment.value;
                selectedAIHasConcerns.value = data.aiHasVulnerabilityConcerns === true;
                selectedAIReviewDateTime.value = (_data$aiReviewDateTim = data.aiReviewDateTime) !== null && _data$aiReviewDateTim !== void 0 ? _data$aiReviewDateTim : selectedAIReviewDateTime.value;
              } else {
                modalErrorMessage.value = result.errorMessage || "Unable to load Lava content.";
              }
            });
            return _openApproval.apply(this, arguments);
          }
          function approveSelected() {
            return _approveSelected.apply(this, arguments);
          }
          function _approveSelected() {
            _approveSelected = _asyncToGenerator(function* () {
              var _selectedSource$value;
              if (!isEditable || !((_selectedSource$value = selectedSource.value) !== null && _selectedSource$value !== void 0 && _selectedSource$value.idKey)) {
                return;
              }
              var result = yield invokeBlockAction("Approve", {
                contentHash: selectedContentHash.value,
                note: ""
              });
              if (result.isSuccess) {
                reloadBlock();
              } else {
                modalErrorMessage.value = result.errorMessage || "Unable to approve Lava content.";
              }
            });
            return _approveSelected.apply(this, arguments);
          }
          function approveRow(_x2) {
            return _approveRow.apply(this, arguments);
          }
          function _approveRow() {
            _approveRow = _asyncToGenerator(function* (idKey) {
              var source = sources.value.find(s => s.idKey === idKey);
              if (!isEditable || !(source !== null && source !== void 0 && source.contentHash)) {
                return;
              }
              var result = yield invokeBlockAction("Approve", {
                contentHash: source.contentHash,
                note: ""
              });
              if (result.isSuccess) {
                reloadBlock();
              } else {
                errorMessage.value = result.errorMessage || "Unable to approve Lava content.";
              }
            });
            return _approveRow.apply(this, arguments);
          }
          function approveSelectedRows(_x3) {
            return _approveSelectedRows.apply(this, arguments);
          }
          function _approveSelectedRows() {
            _approveSelectedRows = _asyncToGenerator(function* (grid) {
              var contentHashes = grid.selectedKeys.filter(k => !!k);
              if (!contentHashes.length) {
                errorMessage.value = "Select one or more Lava approval rows before approving.";
                return;
              }
              if (!confirm("Approve ".concat(contentHashes.length, " Lava approval row").concat(contentHashes.length === 1 ? "" : "s", "?"))) {
                return;
              }
              var _iterator = _createForOfIteratorHelper(contentHashes),
                _step;
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var contentHash = _step.value;
                  var result = yield invokeBlockAction("Approve", {
                    contentHash,
                    note: ""
                  });
                  if (!result.isSuccess) {
                    errorMessage.value = result.errorMessage || "Unable to approve one or more Lava approval rows.";
                    return;
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
              reloadBlock();
            });
            return _approveSelectedRows.apply(this, arguments);
          }
          function reviewSelectedWithAI(_x4) {
            return _reviewSelectedWithAI.apply(this, arguments);
          }
          function _reviewSelectedWithAI() {
            _reviewSelectedWithAI = _asyncToGenerator(function* (grid) {
              var contentHashes = grid.selectedKeys.filter(k => !!k);
              if (!contentHashes.length) {
                errorMessage.value = "Select one or more Lava approval rows before requesting AI review.";
                return;
              }
              isAIReviewInProgress.value = true;
              isAIReviewProgressOpen.value = true;
              aiReviewCompletedCount.value = 0;
              aiReviewTotalCount.value = contentHashes.length;
              aiReviewCurrentHash.value = "";
              aiReviewProgressError.value = "";
              aiReviewErrors.value = [];
              aiReviewProgressMessage.value = "Starting AI review...";
              var nextIndex = 0;
              var workerCount = Math.min(aiReviewConcurrency, contentHashes.length);
              var workers = Array.from({
                length: workerCount
              }, _asyncToGenerator(function* () {
                while (nextIndex < contentHashes.length) {
                  var contentHash = contentHashes[nextIndex++];
                  aiReviewCurrentHash.value = contentHash;
                  aiReviewProgressMessage.value = "Reviewing ".concat(aiReviewCompletedCount.value + 1, " of ").concat(aiReviewTotalCount.value, "...");
                  var result = yield invokeBlockAction("ReviewWithAI", {
                    contentHashes: [contentHash]
                  });
                  if (!result.isSuccess) {
                    aiReviewErrors.value.push("".concat(contentHash, ": ").concat(result.errorMessage || "Unable to review this content."));
                  } else {
                    var _data$skippedCount;
                    var data = result.data;
                    if (((_data$skippedCount = data === null || data === void 0 ? void 0 : data.skippedCount) !== null && _data$skippedCount !== void 0 ? _data$skippedCount : 0) > 0) {
                      var _data$skippedMessages;
                      var skippedMessages = data !== null && data !== void 0 && (_data$skippedMessages = data.skippedMessages) !== null && _data$skippedMessages !== void 0 && _data$skippedMessages.length ? data.skippedMessages : ["".concat(contentHash, ": skipped because the content exceeds the AI review size limit.")];
                      aiReviewErrors.value.push(...skippedMessages);
                    }
                  }
                  aiReviewCompletedCount.value++;
                }
              }));
              try {
                yield Promise.all(workers);
              } catch (error) {
                aiReviewErrors.value.push(error instanceof Error ? error.message : "An unexpected AI review error occurred.");
              }
              aiReviewCurrentHash.value = "";
              isAIReviewInProgress.value = false;
              if (aiReviewErrors.value.length) {
                aiReviewProgressError.value = "".concat(aiReviewErrors.value.length, " review").concat(aiReviewErrors.value.length === 1 ? "" : "s", " failed.");
                aiReviewProgressMessage.value = "AI review finished with errors. Refreshing results...";
              } else {
                aiReviewProgressMessage.value = "AI review complete. Refreshing results...";
              }
              window.setTimeout(() => reloadBlock(), 1000);
            });
            return _reviewSelectedWithAI.apply(this, arguments);
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : (openBlock(), createBlock(unref(Grid), {
              key: 1,
              title: "Lava Approvals",
              data: gridDataSource.value,
              customActions: gridActions.value,
              keyField: "idKey",
              itemTerm: "Lava Script",
              tooltipField: "contentPreview",
              stickyHeader: "",
              onSelectItem: openApproval
            }, {
              default: withCtx(() => [unref(isEditable) ? (openBlock(), createBlock(unref(SelectColumn), {
                key: 0
              })) : createCommentVNode("v-if", true), createVNode(unref(Column), {
                name: "contentPreview",
                title: "Preview",
                sortValue: "{{ row.contentPreview }}",
                filterValue: "{{ row.contentPreview }}",
                quickFilterValue: "{{ row.contentPreview }}",
                filter: unref(textValueFilter),
                width: "45%"
              }, {
                format: withCtx(_ref => {
                  var row = _ref.row;
                  return [createElementVNode("code", _hoisted_1, toDisplayString(row.contentPreview), 1)];
                }),
                _: 1
              }, 8, ["filter"]), createVNode(unref(Column), {
                name: "matchingSourceCount",
                title: "Instances",
                sortValue: "{{ row.matchingSourceSortValue }}",
                filterValue: "{{ row.matchingSourceCount }}",
                quickFilterValue: "{{ row.matchingSourceCount }}",
                filter: unref(numberValueFilter),
                visiblePriority: "sm",
                width: "10%"
              }, {
                format: withCtx(_ref2 => {
                  var row = _ref2.row;
                  return [createTextVNode(toDisplayString(row.matchingSourceCount), 1)];
                }),
                _: 1
              }, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "detectedDateTime",
                title: "Detected",
                field: "detectedDateTime",
                filter: unref(textValueFilter),
                visiblePriority: "sm",
                width: "10%"
              }, null, 8, ["filter"]), createVNode(unref(Column), {
                name: "isPublic",
                title: "Public",
                sortValue: "{{ row.isPublic ? '2' : row.isPublic === false ? '1' : '0' }}",
                filterValue: "{{ row.isPublic ? 'Yes' : row.isPublic === false ? 'No' : 'Unknown' }}",
                quickFilterValue: "{{ row.isPublic ? 'Yes' : row.isPublic === false ? 'No' : 'Unknown' }}",
                filter: unref(pickExistingValueFilter),
                visiblePriority: "sm",
                width: "8%"
              }, {
                format: withCtx(_ref3 => {
                  var row = _ref3.row;
                  return [row.isPublic ? (openBlock(), createElementBlock("span", _hoisted_2, "Public")) : row.isPublic === false ? (openBlock(), createElementBlock("span", _hoisted_3, "No")) : (openBlock(), createElementBlock("span", _hoisted_4, "Unknown"))];
                }),
                _: 1
              }, 8, ["filter"]), createVNode(unref(Column), {
                name: "aiReview",
                title: "AI Review",
                sortValue: "{{ row.aiRiskSortOrder }}",
                filterValue: "{{ row.aiRiskAssessment }}",
                quickFilterValue: "{{ row.aiRiskAssessment }}",
                field: "aiRiskAssessment",
                filter: unref(pickExistingValueFilter),
                visiblePriority: "sm",
                width: "10%"
              }, {
                format: withCtx(_ref4 => {
                  var _row$aiRiskAssessment;
                  var row = _ref4.row;
                  return [row.aiReviewDateTime ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: normalizeClass(["ai-review-status", "risk-".concat((_row$aiRiskAssessment = row.aiRiskAssessment) !== null && _row$aiRiskAssessment !== void 0 ? _row$aiRiskAssessment : 'unknown')])
                  }, toDisplayString(row.aiRiskAssessment || "unknown"), 3)) : (openBlock(), createElementBlock("span", _hoisted_5, "Not reviewed"))];
                }),
                _: 1
              }, 8, ["filter"]), createVNode(unref(Column), {
                name: "shortcodeAiReview",
                title: "Shortcode Risk",
                sortValue: "{{ row.shortcodeAiRiskSortOrder }}",
                filterValue: "{{ row.shortcodeAiRiskAssessment }}",
                quickFilterValue: "{{ row.shortcodeAiRiskAssessment }}",
                field: "shortcodeAiRiskAssessment",
                filter: unref(pickExistingValueFilter),
                visiblePriority: "sm",
                width: "10%"
              }, {
                format: withCtx(_ref5 => {
                  var _row$shortcodeAiRiskA;
                  var row = _ref5.row;
                  return [row.shortcodeAiRiskAssessment ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: normalizeClass(["ai-review-status", "risk-".concat((_row$shortcodeAiRiskA = row.shortcodeAiRiskAssessment) !== null && _row$shortcodeAiRiskA !== void 0 ? _row$shortcodeAiRiskA : 'unknown')])
                  }, toDisplayString(row.shortcodeAiRiskAssessment), 3)) : createCommentVNode("v-if", true)];
                }),
                _: 1
              }, 8, ["filter"]), unref(isEditable) ? (openBlock(), createBlock(unref(Column), {
                key: 1,
                name: "approve",
                title: "Approve",
                width: "5%"
              }, {
                format: withCtx(_ref6 => {
                  var row = _ref6.row;
                  return [createVNode(unref(RockButton), {
                    btnType: "primary",
                    onClick: withModifiers($event => approveRow(row.idKey), ["stop"])
                  }, {
                    default: withCtx(() => [createTextVNode("Approve")]),
                    _: 2
                  }, 1032, ["onClick"])];
                }),
                _: 1
              })) : createCommentVNode("v-if", true)]),
              _: 1
            }, 8, ["data", "customActions"])), createVNode(unref(Modal), {
              modelValue: isModalOpen.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isModalOpen.value = $event),
              title: "Review Lava Approval",
              saveText: unref(isEditable) ? 'Approve' : '',
              onSave: approveSelected
            }, {
              default: withCtx(() => [modalErrorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: unref(AlertType).Warning
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(modalErrorMessage.value), 1)]),
                _: 1
              }, 8, ["alertType"])) : createCommentVNode("v-if", true), selectedSource.value ? (openBlock(), createElementBlock(Fragment, {
                key: 1
              }, [createElementVNode("dl", null, [_hoisted_6, createElementVNode("dd", null, toDisplayString(selectedSource.value.matchingSourceCount) + " place" + toDisplayString(selectedSource.value.matchingSourceCount === 1 ? "" : "s"), 1), _hoisted_7, createElementVNode("dd", null, toDisplayString(selectedSource.value.isPublic ? "Yes" : selectedSource.value.isPublic === false ? "No" : "Unknown"), 1), _hoisted_8, createElementVNode("dd", null, [createElementVNode("code", null, toDisplayString(selectedContentHash.value), 1)])]), selectedAIRiskAssessment.value == 'high' ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: unref(AlertType).Danger
              }, {
                default: withCtx(() => [_hoisted_9, createTextVNode(" This Lava content has been identified as high risk by AI review or raised because it is public. Exercise caution when approving or using this content. ")]),
                _: 1
              }, 8, ["alertType"])) : createCommentVNode("v-if", true), selectedAIRiskAssessment.value == 'urgent' ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 1,
                alertType: unref(AlertType).Danger
              }, {
                default: withCtx(() => [_hoisted_10, createTextVNode(" This Lava content is public and has been raised from high risk by AI review. Exercise caution when approving or using this content. ")]),
                _: 1
              }, 8, ["alertType"])) : createCommentVNode("v-if", true), selectedAIReviewDetails.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 2,
                alertType: selectedAIHasConcerns.value ? unref(AlertType).Warning : unref(AlertType).Info
              }, {
                default: withCtx(() => [_hoisted_11, createTextVNode(" " + toDisplayString(selectedAIRiskAssessment.value || "unknown") + " risk. " + toDisplayString(selectedAIReviewDetails.value) + " ", 1), selectedAIReviewDateTime.value ? (openBlock(), createElementBlock("span", _hoisted_12, "Reviewed " + toDisplayString(selectedAIReviewDateTime.value) + ".", 1)) : createCommentVNode("v-if", true)]),
                _: 1
              }, 8, ["alertType"])) : createCommentVNode("v-if", true), selectedSources.value.length ? (openBlock(), createElementBlock("table", _hoisted_13, [_hoisted_14, createElementVNode("tbody", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(selectedSources.value, source => {
                var _ref7, _source$idKey, _source$entityDetails, _source$shortcodeAiRi;
                return openBlock(), createElementBlock("tr", {
                  key: (_ref7 = (_source$idKey = source.idKey) !== null && _source$idKey !== void 0 ? _source$idKey : source.source) !== null && _ref7 !== void 0 ? _ref7 : source.rowId
                }, [createElementVNode("td", null, [createElementVNode("div", null, toDisplayString(source.source), 1), (_source$entityDetails = source.entityDetails) !== null && _source$entityDetails !== void 0 && _source$entityDetails.length ? (openBlock(), createElementBlock("dl", _hoisted_15, [(openBlock(true), createElementBlock(Fragment, null, renderList(source.entityDetails, detail => {
                  return openBlock(), createElementBlock(Fragment, {
                    key: "".concat(detail.label, ":").concat(detail.value, ":").concat(detail.url)
                  }, [createElementVNode("dt", null, toDisplayString(detail.label), 1), createElementVNode("dd", null, [detail.url ? (openBlock(), createElementBlock("a", {
                    key: 0,
                    href: detail.url,
                    target: "_blank",
                    rel: "noopener noreferrer"
                  }, toDisplayString(detail.value), 9, _hoisted_16)) : (openBlock(), createElementBlock("span", _hoisted_17, toDisplayString(detail.value), 1))])], 64);
                }), 128))])) : createCommentVNode("v-if", true)]), createElementVNode("td", null, [source.isPublic ? (openBlock(), createElementBlock("span", _hoisted_18, "Public")) : source.isPublic === false ? (openBlock(), createElementBlock("span", _hoisted_19, "No")) : (openBlock(), createElementBlock("span", _hoisted_20, "Unknown"))]), createElementVNode("td", null, [source.shortcodeAiRiskAssessment ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(["ai-review-status", "risk-".concat((_source$shortcodeAiRi = source.shortcodeAiRiskAssessment) !== null && _source$shortcodeAiRi !== void 0 ? _source$shortcodeAiRi : 'unknown')])
                }, toDisplayString(source.shortcodeAiRiskAssessment), 3)) : createCommentVNode("v-if", true)]), createElementVNode("td", null, toDisplayString(source.detectedDateTime), 1)]);
              }), 128))])])) : createCommentVNode("v-if", true), createElementVNode("div", _hoisted_21, [selectedContent.value ? (openBlock(), createElementBlock("pre", _hoisted_22, toDisplayString(selectedContent.value), 1)) : (openBlock(), createElementBlock("p", _hoisted_23, "Loading content..."))])], 64)) : createCommentVNode("v-if", true)]),
              _: 1
            }, 8, ["modelValue", "saveText"]), createVNode(unref(Modal), {
              modelValue: isAIReviewProgressOpen.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => isAIReviewProgressOpen.value = $event),
              title: "AI Review Progress",
              saveText: ""
            }, {
              default: withCtx(() => [aiReviewProgressError.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: unref(AlertType).Warning
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(aiReviewProgressError.value), 1)]),
                _: 1
              }, 8, ["alertType"])) : createCommentVNode("v-if", true), createElementVNode("div", _hoisted_24, [createElementVNode("p", null, toDisplayString(aiReviewProgressMessage.value), 1), createElementVNode("div", _hoisted_25, [createElementVNode("div", {
                class: "progress-bar",
                role: "progressbar",
                style: normalizeStyle({
                  width: "".concat(aiReviewProgressPercent.value, "%")
                })
              }, toDisplayString(aiReviewCompletedCount.value) + " / " + toDisplayString(aiReviewTotalCount.value), 5)]), aiReviewCurrentHash.value ? (openBlock(), createElementBlock("p", _hoisted_26, [createTextVNode(" Reviewing "), createElementVNode("code", null, toDisplayString(aiReviewCurrentHash.value), 1)])) : createCommentVNode("v-if", true), aiReviewErrors.value.length ? (openBlock(), createElementBlock("ul", _hoisted_27, [(openBlock(true), createElementBlock(Fragment, null, renderList(aiReviewErrors.value, error => {
                return openBlock(), createElementBlock("li", {
                  key: error
                }, toDisplayString(error), 1);
              }), 128))])) : createCommentVNode("v-if", true)])]),
              _: 1
            }, 8, ["modelValue"])]);
          };
        }
      }));

      function styleInject(css, ref) {
        if (ref === void 0) ref = {};
        var insertAt = ref.insertAt;
        if (!css || typeof document === 'undefined') {
          return;
        }
        var head = document.head || document.getElementsByTagName('head')[0];
        var style = document.createElement('style');
        style.type = 'text/css';
        if (insertAt === 'top') {
          if (head.firstChild) {
            head.insertBefore(style, head.firstChild);
          } else {
            head.appendChild(style);
          }
        } else {
          head.appendChild(style);
        }
        if (style.styleSheet) {
          style.styleSheet.cssText = css;
        } else {
          style.appendChild(document.createTextNode(css));
        }
      }

      var css_248z = ".lava-preview[data-v-5570eb54]{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.source-table[data-v-5570eb54]{border-collapse:collapse;margin-bottom:16px;width:100%}.source-table td[data-v-5570eb54],.source-table th[data-v-5570eb54]{border-bottom:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}.approval-content[data-v-5570eb54]{max-height:60vh;overflow:auto}.entity-details[data-v-5570eb54]{display:grid;gap:2px 8px;grid-template-columns:max-content 1fr;margin:6px 0 0}.entity-details dt[data-v-5570eb54]{color:#666;font-weight:600;margin:0}.entity-details dd[data-v-5570eb54]{margin:0}.approval-content pre[data-v-5570eb54]{white-space:pre-wrap;word-break:break-word}.ai-review-status[data-v-5570eb54]{border-radius:999px;display:inline-block;font-size:12px;font-weight:600;padding:2px 8px;text-transform:capitalize}.risk-low[data-v-5570eb54]{background:#e6f4ea;color:#137333}.risk-medium[data-v-5570eb54],.risk-unknown[data-v-5570eb54]{background:#fef7e0;color:#b06000}.risk-high[data-v-5570eb54]{background:#fce8e6;color:#c5221f}.public-status[data-v-5570eb54],.risk-urgent[data-v-5570eb54]{background:#fce8e6;border-radius:999px;color:#8b0000;display:inline-block;font-size:12px;font-weight:700;padding:2px 8px;text-transform:capitalize}.ai-review-progress .progress[data-v-5570eb54]{margin-bottom:12px}.ai-review-errors[data-v-5570eb54]{margin-top:12px;max-height:240px;overflow:auto}";
      styleInject(css_248z);

      script.__scopeId = "data-v-5570eb54";
      script.__file = "src/lavaApprovalList.obs";

    })
  };
}));
//# sourceMappingURL=lavaApprovalList.obs.js.map
