System.register(['vue', '@Obsidian/Controls/grid', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createVNode, createElementVNode, createCommentVNode, Grid, Column, textValueFilter, BooleanColumn, booleanValueFilter, NumberColumn, TextColumn, DeleteColumn, NotificationBox, AlertType, useConfigurationValues, useInvokeBlockAction, useReloadBlock;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createVNode = module.createVNode;
      createElementVNode = module.createElementVNode;
      createCommentVNode = module.createCommentVNode;
    }, function (module) {
      Grid = module["default"];
      Column = module.Column;
      textValueFilter = module.textValueFilter;
      BooleanColumn = module.BooleanColumn;
      booleanValueFilter = module.booleanValueFilter;
      NumberColumn = module.NumberColumn;
      TextColumn = module.TextColumn;
      DeleteColumn = module.DeleteColumn;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      useReloadBlock = module.useReloadBlock;
    }],
    execute: (function () {

      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }

      var _hoisted_1 = {
        class: "text-muted"
      };
      var script = exports('default', defineComponent({
        __name: 'iisAlertList',
        setup(__props) {
          var _config$alerts, _config$errorMessage;
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          var reloadBlock = useReloadBlock();
          var alerts = ref((_config$alerts = config.alerts) !== null && _config$alerts !== void 0 ? _config$alerts : []);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var isEditable = config.isEditable;
          var gridDataSource = computed(() => Promise.resolve({
            rows: alerts.value
          }));
          function buildUrl(template, idKey) {
            return (template || "").replace("((IdKey))", encodeURIComponent(idKey));
          }
          function goToAlert(idKey) {
            if (idKey) {
              window.location.href = buildUrl(config.detailPageUrl, idKey);
            }
          }
          function goToNewAlert() {
            window.location.href = buildUrl(config.detailPageUrl, "0");
          }
          function deleteAlert(_x) {
            return _deleteAlert.apply(this, arguments);
          }
          function _deleteAlert() {
            _deleteAlert = _asyncToGenerator(function* (idKey) {
              var alert = alerts.value.find(a => a.idKey === idKey);
              if (!idKey || !confirm("Delete ".concat((alert === null || alert === void 0 ? void 0 : alert.name) || "this alert", "?"))) {
                return;
              }
              var result = yield invokeBlockAction("DeleteAlert", {
                idKey
              });
              if (result.isSuccess) {
                reloadBlock();
              } else {
                errorMessage.value = result.errorMessage || "Unable to delete alert.";
              }
            });
            return _deleteAlert.apply(this, arguments);
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : (openBlock(), createBlock(unref(Grid), {
              key: 1,
              title: "IIS Alerts",
              data: gridDataSource.value,
              keyField: "idKey",
              itemTerm: "IIS Alert",
              tooltipField: "name",
              stickyHeader: "",
              onAddItem: unref(isEditable) ? goToNewAlert : undefined,
              onSelectItem: goToAlert
            }, {
              default: withCtx(() => [createVNode(unref(Column), {
                name: "name",
                title: "Name",
                sortValue: "{{ row.name }} {{ row.description }}",
                filterValue: "{{ row.name }} {{ row.description }}",
                quickFilterValue: "{{ row.name }} {{ row.description }}",
                filter: unref(textValueFilter),
                width: "45%"
              }, {
                format: withCtx(_ref => {
                  var row = _ref.row;
                  return [createElementVNode("strong", null, toDisplayString(row.name), 1), createElementVNode("div", _hoisted_1, toDisplayString(row.description), 1)];
                }),
                _: 1
              }, 8, ["filter"]), createVNode(unref(BooleanColumn), {
                name: "isActive",
                title: "Active",
                field: "isActive",
                filter: unref(booleanValueFilter),
                visiblePriority: "xs",
                width: "10%"
              }, null, 8, ["filter"]), createVNode(unref(NumberColumn), {
                name: "evaluationFrequencyMinutes",
                title: "Frequency Minutes",
                field: "evaluationFrequencyMinutes",
                visiblePriority: "sm",
                width: "15%"
              }), createVNode(unref(TextColumn), {
                name: "lastRunDateTime",
                title: "Last Run",
                field: "lastRunDateTime",
                filter: unref(textValueFilter),
                visiblePriority: "sm",
                width: "20%"
              }, null, 8, ["filter"]), unref(isEditable) ? (openBlock(), createBlock(unref(DeleteColumn), {
                key: 0,
                onClick: deleteAlert
              })) : createCommentVNode("v-if", true)]),
              _: 1
            }, 8, ["data", "onAddItem"]))]);
          };
        }
      }));

      script.__file = "src/iisAlertList.obs";

    })
  };
}));
//# sourceMappingURL=iisAlertList.obs.js.map
