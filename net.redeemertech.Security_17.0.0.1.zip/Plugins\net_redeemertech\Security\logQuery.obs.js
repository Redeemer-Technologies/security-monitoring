System.register(['vue', '@Obsidian/Controls/codeEditor.obs', '@Obsidian/Controls/grid', '@Obsidian/Controls/loadingIndicator.obs', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/panel.obs', '@Obsidian/Controls/rockButton.obs', '@Obsidian/Controls/slidingDateRangePicker.obs', '@Obsidian/Core/Controls/grid', '@Obsidian/Core/Utilities/domUtils', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Enums/Controls/slidingDateRangeType', '@Obsidian/Utility/block', '@Obsidian/Utility/objectUtils'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, watch, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createCommentVNode, createVNode, Fragment, pushScopeId, popScopeId, createElementVNode, CodeEditor, defaultColumnFilters, pickExistingValueFilter, Grid, DynamicColumns, TextColumn, BooleanColumn, CurrencyColumn, DateColumn, DateTimeColumn, HtmlColumn, NumberColumn, LoadingIndicator, NotificationBox, Panel, RockButton, SlidingDateRangePicker, getRowKey, setInnerHTML, AlertType, SlidingDateRangeType, useConfigurationValues, useInvokeBlockAction, useReloadBlock, onConfigurationValuesChanged, getValueFromPath;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      watch = module.watch;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createCommentVNode = module.createCommentVNode;
      createVNode = module.createVNode;
      Fragment = module.Fragment;
      pushScopeId = module.pushScopeId;
      popScopeId = module.popScopeId;
      createElementVNode = module.createElementVNode;
    }, function (module) {
      CodeEditor = module["default"];
    }, function (module) {
      defaultColumnFilters = module.defaultColumnFilters;
      pickExistingValueFilter = module.pickExistingValueFilter;
      Grid = module["default"];
      DynamicColumns = module.DynamicColumns;
      TextColumn = module.TextColumn;
      BooleanColumn = module.BooleanColumn;
      CurrencyColumn = module.CurrencyColumn;
      DateColumn = module.DateColumn;
      DateTimeColumn = module.DateTimeColumn;
      HtmlColumn = module.HtmlColumn;
      NumberColumn = module.NumberColumn;
    }, function (module) {
      LoadingIndicator = module["default"];
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      Panel = module["default"];
    }, function (module) {
      RockButton = module["default"];
    }, function (module) {
      SlidingDateRangePicker = module["default"];
    }, function (module) {
      getRowKey = module.getRowKey;
    }, function (module) {
      setInnerHTML = module.setInnerHTML;
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      SlidingDateRangeType = module.SlidingDateRangeType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      useReloadBlock = module.useReloadBlock;
      onConfigurationValuesChanged = module.onConfigurationValuesChanged;
    }, function (module) {
      getValueFromPath = module.getValueFromPath;
    }],
    execute: (function () {

      function ownKeys(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          r && (o = o.filter(function (r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
          })), t.push.apply(t, o);
        }
        return t;
      }
      function _objectSpread2(e) {
        for (var r = 1; r < arguments.length; r++) {
          var t = null != arguments[r] ? arguments[r] : {};
          r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
            _defineProperty(e, r, t[r]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
          });
        }
        return e;
      }
      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }
      function _defineProperty(obj, key, value) {
        key = _toPropertyKey(key);
        if (key in obj) {
          Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        } else {
          obj[key] = value;
        }
        return obj;
      }
      function _toPrimitive(input, hint) {
        if (typeof input !== "object" || input === null) return input;
        var prim = input[Symbol.toPrimitive];
        if (prim !== undefined) {
          var res = prim.call(input, hint || "default");
          if (typeof res !== "object") return res;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return (hint === "string" ? String : Number)(input);
      }
      function _toPropertyKey(arg) {
        var key = _toPrimitive(arg, "string");
        return typeof key === "symbol" ? key : String(key);
      }

      var _withScopeId = n => (pushScopeId("data-v-0cd0fa37"), n = n(), popScopeId(), n);
      var _hoisted_1 = {
        class: "log-query"
      };
      var _hoisted_2 = _withScopeId(() => createElementVNode("i", {
        class: "fa fa-play",
        "aria-hidden": ""
      }, null, -1));
      var rowSelectionNavigationUrlKey = "RowSelection";
      var script = exports('default', defineComponent({
        __name: 'logQuery',
        setup(__props) {
          var _config$errorMessage, _ref, _config$currentQuery, _config$dateRange;
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          var reloadBlock = useReloadBlock();
          var columnComponents = {
            "boolean": BooleanColumn,
            "currency": CurrencyColumn,
            "date": DateColumn,
            "dateTime": DateTimeColumn,
            "html": HtmlColumn,
            "number": NumberColumn,
            "text": TextColumn
          };
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var isLoading = ref(false);
          var showQueryOnPage = ref(config.showQueryOnPage);
          var pageQuery = ref((_ref = (_config$currentQuery = config.currentQuery) !== null && _config$currentQuery !== void 0 ? _config$currentQuery : config.defaultQuery) !== null && _ref !== void 0 ? _ref : "");
          var dateRange = ref((_config$dateRange = config.dateRange) !== null && _config$dateRange !== void 0 ? _config$dateRange : null);
          var gridResults = ref();
          var gridData = ref({});
          var navigationUrls = ref();
          var lavaTemplateResults = ref();
          var lavaTemplateResultsElement = ref(null);
          var enabledSlidingDateRangeUnits = [SlidingDateRangeType.Previous, SlidingDateRangeType.Last, SlidingDateRangeType.Current, SlidingDateRangeType.DateRange];
          var gridDataSource = computed(() => Promise.resolve(gridData.value));
          var gridDefinition = computed(() => {
            var _gridResults$value;
            return (_gridResults$value = gridResults.value) === null || _gridResults$value === void 0 ? void 0 : _gridResults$value.gridDefinition;
          });
          var gridTitle = computed(() => {
            var _gridResults$value$ti, _gridResults$value2;
            return (_gridResults$value$ti = (_gridResults$value2 = gridResults.value) === null || _gridResults$value2 === void 0 ? void 0 : _gridResults$value2.title) !== null && _gridResults$value$ti !== void 0 ? _gridResults$value$ti : undefined;
          });
          var isGridTitleHidden = computed(() => !gridTitle.value);
          var isLavaTemplateDisplayMode = computed(() => config.isLavaTemplateDisplayMode && !errorMessage.value);
          var lavaTemplateResultsHtml = computed(() => {
            var _lavaTemplateResults$;
            return (_lavaTemplateResults$ = lavaTemplateResults.value) === null || _lavaTemplateResults$ === void 0 ? void 0 : _lavaTemplateResults$.resultsHtml;
          });
          var dynamicFields = computed(() => {
            var _gridDefinition$value, _gridDefinition$value2;
            return (_gridDefinition$value = (_gridDefinition$value2 = gridDefinition.value) === null || _gridDefinition$value2 === void 0 || (_gridDefinition$value2 = _gridDefinition$value2.dynamicFields) === null || _gridDefinition$value2 === void 0 || (_gridDefinition$value2 = _gridDefinition$value2.filter(field => !!field.columnType)) === null || _gridDefinition$value2 === void 0 ? void 0 : _gridDefinition$value2.map(field => {
              var _field$columnType;
              var filter = defaultColumnFilters[(_field$columnType = field.columnType) !== null && _field$columnType !== void 0 ? _field$columnType : ""];
              if (!filter && field.columnType !== "html") {
                filter = pickExistingValueFilter;
              }
              return _objectSpread2(_objectSpread2({}, field), {}, {
                filter: field.enableFiltering ? filter : undefined
              });
            })) !== null && _gridDefinition$value !== void 0 ? _gridDefinition$value : [];
          });
          function loadResults(_x) {
            return _loadResults.apply(this, arguments);
          }
          function _loadResults() {
            _loadResults = _asyncToGenerator(function* (saveUserPreference) {
              var _result$data$gridData, _result$data$navigati;
              isLoading.value = true;
              errorMessage.value = "";
              var bag = {
                query: pageQuery.value,
                dateRange: dateRange.value,
                saveUserPreference
              };
              var result = yield invokeBlockAction("GetLogQueryResults", {
                bag
              });
              isLoading.value = false;
              if (!result.isSuccess || !result.data) {
                gridResults.value = undefined;
                gridData.value = {};
                navigationUrls.value = null;
                lavaTemplateResults.value = undefined;
                errorMessage.value = result.errorMessage || "Unknown error while trying to run the log query.";
                return;
              }
              gridResults.value = result.data.gridResults;
              gridData.value = (_result$data$gridData = result.data.gridData) !== null && _result$data$gridData !== void 0 ? _result$data$gridData : {};
              navigationUrls.value = (_result$data$navigati = result.data.navigationUrls) !== null && _result$data$navigati !== void 0 ? _result$data$navigati : null;
              lavaTemplateResults.value = result.data.lavaTemplateResults;
            });
            return _loadResults.apply(this, arguments);
          }
          function onRunClick() {
            return _onRunClick.apply(this, arguments);
          }
          function _onRunClick() {
            _onRunClick = _asyncToGenerator(function* () {
              yield loadResults(true);
            });
            return _onRunClick.apply(this, arguments);
          }
          function onSelectItem(rowKey) {
            var _navigationUrls$value, _gridData$value$rows;
            var rowSelectionUrl = (_navigationUrls$value = navigationUrls.value) === null || _navigationUrls$value === void 0 ? void 0 : _navigationUrls$value[rowSelectionNavigationUrlKey];
            if (!rowSelectionUrl) {
              return;
            }
            if (rowSelectionUrl.startsWith("~")) {
              rowSelectionUrl = "".concat(window.location.origin).concat(rowSelectionUrl.substring(1));
            }
            var columnKeys = rowSelectionUrl.match(/\(\([\w\s]+\)\)/g);
            if (!(columnKeys !== null && columnKeys !== void 0 && columnKeys.length)) {
              window.location.href = rowSelectionUrl;
              return;
            }
            var row = (_gridData$value$rows = gridData.value.rows) === null || _gridData$value$rows === void 0 ? void 0 : _gridData$value$rows.find(r => getRowKey(r, "uniqueKey") === rowKey);
            if (!row) {
              return;
            }
            columnKeys.forEach(columnKey => {
              var columnName = columnKey.replace(/\(|\)/g, "");
              var columnValue = encodeURIComponent(String(getValueFromPath(row, columnName)));
              if (columnValue) {
                var _rowSelectionUrl;
                rowSelectionUrl = (_rowSelectionUrl = rowSelectionUrl) === null || _rowSelectionUrl === void 0 ? void 0 : _rowSelectionUrl.replace(columnKey, columnValue);
              }
            });
            window.location.href = rowSelectionUrl;
          }
          watch([lavaTemplateResultsElement, lavaTemplateResultsHtml], () => {
            if (lavaTemplateResultsElement.value && lavaTemplateResultsHtml.value) {
              setInnerHTML(lavaTemplateResultsElement.value, lavaTemplateResultsHtml.value);
            }
          });
          loadResults(false);
          onConfigurationValuesChanged(reloadBlock);
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", _hoisted_1, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : createCommentVNode("v-if", true), showQueryOnPage.value ? (openBlock(), createBlock(unref(Panel), {
              key: 1,
              title: "Log Query",
              class: "log-query-editor"
            }, {
              default: withCtx(() => [createVNode(unref(CodeEditor), {
                modelValue: pageQuery.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => pageQuery.value = $event),
                label: "SQL Query",
                help: "Use [[logs]] in the FROM clause as the IIS log parquet source. Running this query saves it only to your block preferences.",
                mode: "sql",
                rows: 12
              }, null, 8, ["modelValue"]), createVNode(unref(SlidingDateRangePicker), {
                modelValue: dateRange.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => dateRange.value = $event),
                label: "Date Range",
                help: "Only parquet files whose filename date stamp falls within this range will be included.",
                class: "log-query-date-range",
                previewLocation: "Right",
                enabledSlidingDateRangeUnits: enabledSlidingDateRangeUnits
              }, null, 8, ["modelValue"]), createVNode(unref(RockButton), {
                btnType: "primary",
                disabled: isLoading.value,
                onClick: onRunClick
              }, {
                default: withCtx(() => [_hoisted_2, createTextVNode(" Run ")]),
                _: 1
              }, 8, ["disabled"])]),
              _: 1
            })) : createCommentVNode("v-if", true), isLoading.value ? (openBlock(), createBlock(unref(LoadingIndicator), {
              key: 2,
              delay: 500
            })) : (openBlock(), createElementBlock(Fragment, {
              key: 3
            }, [isLavaTemplateDisplayMode.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              ref_key: "lavaTemplateResultsElement",
              ref: lavaTemplateResultsElement,
              class: "log-query-lava-results"
            }, null, 512)) : gridDefinition.value ? (openBlock(), createBlock(unref(Grid), {
              key: 1,
              data: gridDataSource.value,
              definition: gridDefinition.value,
              title: gridTitle.value,
              exportTitle: gridTitle.value,
              isTitleHidden: isGridTitleHidden.value,
              keyField: "uniqueKey",
              liveUpdates: true,
              onSelectItem: onSelectItem
            }, {
              default: withCtx(() => [createVNode(unref(DynamicColumns), {
                dynamicFields: dynamicFields.value,
                columnComponents: columnComponents,
                defaultColumnComponent: unref(TextColumn)
              }, null, 8, ["dynamicFields", "defaultColumnComponent"])]),
              _: 1
            }, 8, ["data", "definition", "title", "exportTitle", "isTitleHidden"])) : createCommentVNode("v-if", true)], 64))]);
          };
        }
      }));

      function styleInject(css, ref) {
        if (ref === void 0) ref = {};
        var insertAt = ref.insertAt;
        if (!css || typeof document === 'undefined') {
          return;
        }
        var head = document.head || document.getElementsByTagName('head')[0];
        var style = document.createElement('style');
        style.type = 'text/css';
        if (insertAt === 'top') {
          if (head.firstChild) {
            head.insertBefore(style, head.firstChild);
          } else {
            head.appendChild(style);
          }
        } else {
          head.appendChild(style);
        }
        if (style.styleSheet) {
          style.styleSheet.cssText = css;
        } else {
          style.appendChild(document.createTextNode(css));
        }
      }

      var css_248z = ".log-query-date-range[data-v-0cd0fa37],.log-query-editor[data-v-0cd0fa37]{margin-bottom:1rem}";
      styleInject(css_248z);

      script.__scopeId = "data-v-0cd0fa37";
      script.__file = "src/logQuery.obs";

    })
  };
}));
//# sourceMappingURL=logQuery.obs.js.map
