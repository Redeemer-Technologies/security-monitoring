System.register(['vue', '@Obsidian/Controls/buttonGroup.obs', '@Obsidian/Controls/codeEditor.obs', '@Obsidian/Controls/loadingIndicator.obs', '@Obsidian/Controls/modal.obs', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Controls/numberBox.obs', '@Obsidian/Controls/sectionHeader.obs', '@Obsidian/Controls/slidingDateRangePicker.obs', '@Obsidian/Controls/switch.obs', '@Obsidian/Controls/textBox.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Enums/Controls/slidingDateRangeType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var createElementVNode, defineComponent, ref, computed, watch, openBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createElementBlock, Fragment, createVNode, ButtonGroup, CodeEditor, LoadingIndicator, Modal, NotificationBox, NumberBox, SectionHeader, SlidingDateRangePicker, Switch, TextBox, AlertType, SlidingDateRangeType, useInvokeBlockAction, getSecurityGrant, useReloadBlock, provideSecurityGrant, setCustomSettingsBoxValue;
  return {
    setters: [function (module) {
      createElementVNode = module.createElementVNode;
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      watch = module.watch;
      openBlock = module.openBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createElementBlock = module.createElementBlock;
      Fragment = module.Fragment;
      createVNode = module.createVNode;
    }, function (module) {
      ButtonGroup = module["default"];
    }, function (module) {
      CodeEditor = module["default"];
    }, function (module) {
      LoadingIndicator = module["default"];
    }, function (module) {
      Modal = module["default"];
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      NumberBox = module["default"];
    }, function (module) {
      SectionHeader = module["default"];
    }, function (module) {
      SlidingDateRangePicker = module["default"];
    }, function (module) {
      Switch = module["default"];
    }, function (module) {
      TextBox = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      SlidingDateRangeType = module.SlidingDateRangeType;
    }, function (module) {
      useInvokeBlockAction = module.useInvokeBlockAction;
      getSecurityGrant = module.getSecurityGrant;
      useReloadBlock = module.useReloadBlock;
      provideSecurityGrant = module.provideSecurityGrant;
      setCustomSettingsBoxValue = module.setCustomSettingsBoxValue;
    }],
    execute: (function () {

      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }

      var _hoisted_1 = {
        class: "row"
      };
      var _hoisted_2 = {
        class: "col-md-6"
      };
      var _hoisted_3 = createElementVNode("span", {
        class: "input-group-addon"
      }, "sec", -1);
      var _hoisted_4 = {
        class: "col-md-6"
      };
      var _hoisted_5 = {
        class: "form-group"
      };
      var script = exports('default', defineComponent({
        __name: 'logQueryCustomSettings',
        emits: ["close"],
        setup(__props, _ref) {
          var __emit = _ref.emit;
          var invokeBlockAction = useInvokeBlockAction();
          var securityGrant = getSecurityGrant(null);
          var reloadBlock = useReloadBlock();
          var emit = __emit;
          var displayMode = {
            grid: "grid",
            lavaTemplate: "lavaTemplate"
          };
          var errorMessage = ref("");
          var isLoading = ref(true);
          var isModalOpen = ref(true);
          var query = ref("");
          var queryParams = ref("");
          var dateRange = ref(null);
          var timeout = ref(null);
          var resultsDisplayMode = ref(displayMode.grid);
          var gridTitle = ref("");
          var selectionUrl = ref("");
          var lavaTemplate = ref("");
          var showQueryOnPage = ref(false);
          var displayModeItems = ref([]);
          var enabledSlidingDateRangeUnits = [SlidingDateRangeType.Previous, SlidingDateRangeType.Last, SlidingDateRangeType.Current, SlidingDateRangeType.DateRange];
          var stdDisplayModeItems = computed(() => {
            var _displayModeItems$val, _displayModeItems$val2;
            return (_displayModeItems$val = (_displayModeItems$val2 = displayModeItems.value) === null || _displayModeItems$val2 === void 0 ? void 0 : _displayModeItems$val2.filter(mode => !!(mode.text && mode.value)).map(mode => {
              var _mode$text, _mode$value;
              return {
                text: (_mode$text = mode.text) !== null && _mode$text !== void 0 ? _mode$text : "",
                value: (_mode$value = mode.value) !== null && _mode$value !== void 0 ? _mode$value : ""
              };
            })) !== null && _displayModeItems$val !== void 0 ? _displayModeItems$val : [];
          });
          var isLavaTemplateDisplayMode = computed(() => resultsDisplayMode.value === displayMode.lavaTemplate);
          var saveButtonText = computed(() => errorMessage.value || !isLoading.value ? "Save" : "");
          function startLoading() {
            return _startLoading.apply(this, arguments);
          }
          function _startLoading() {
            _startLoading = _asyncToGenerator(function* () {
              var result = yield invokeBlockAction("GetCustomSettings");
              if (result.isSuccess && result.data && result.data.settings && result.data.options) {
                var _result$data$settings, _result$data$settings2, _result$data$settings3, _result$data$settings4, _result$data$settings5, _result$data$settings6, _result$data$settings7, _result$data$settings8, _result$data$options$;
                query.value = (_result$data$settings = result.data.settings.query) !== null && _result$data$settings !== void 0 ? _result$data$settings : "";
                queryParams.value = (_result$data$settings2 = result.data.settings.queryParams) !== null && _result$data$settings2 !== void 0 ? _result$data$settings2 : "";
                dateRange.value = (_result$data$settings3 = result.data.settings.dateRange) !== null && _result$data$settings3 !== void 0 ? _result$data$settings3 : null;
                timeout.value = (_result$data$settings4 = result.data.settings.timeout) !== null && _result$data$settings4 !== void 0 ? _result$data$settings4 : null;
                resultsDisplayMode.value = (_result$data$settings5 = result.data.settings.resultsDisplayMode) !== null && _result$data$settings5 !== void 0 ? _result$data$settings5 : displayMode.grid;
                gridTitle.value = (_result$data$settings6 = result.data.settings.gridTitle) !== null && _result$data$settings6 !== void 0 ? _result$data$settings6 : "";
                selectionUrl.value = (_result$data$settings7 = result.data.settings.selectionUrl) !== null && _result$data$settings7 !== void 0 ? _result$data$settings7 : "";
                lavaTemplate.value = (_result$data$settings8 = result.data.settings.lavaTemplate) !== null && _result$data$settings8 !== void 0 ? _result$data$settings8 : "";
                showQueryOnPage.value = result.data.settings.showQueryOnPage;
                securityGrant.updateToken(result.data.securityGrantToken);
                displayModeItems.value = (_result$data$options$ = result.data.options.displayModeItems) !== null && _result$data$options$ !== void 0 ? _result$data$options$ : [];
              } else {
                errorMessage.value = result.errorMessage || "Unknown error while loading custom settings.";
              }
              isLoading.value = false;
            });
            return _startLoading.apply(this, arguments);
          }
          function onSave() {
            return _onSave.apply(this, arguments);
          }
          function _onSave() {
            _onSave = _asyncToGenerator(function* () {
              var box = {};
              setCustomSettingsBoxValue(box, "query", query.value);
              setCustomSettingsBoxValue(box, "queryParams", queryParams.value);
              setCustomSettingsBoxValue(box, "dateRange", dateRange.value);
              setCustomSettingsBoxValue(box, "timeout", timeout.value);
              setCustomSettingsBoxValue(box, "resultsDisplayMode", resultsDisplayMode.value);
              setCustomSettingsBoxValue(box, "gridTitle", gridTitle.value);
              setCustomSettingsBoxValue(box, "selectionUrl", selectionUrl.value);
              setCustomSettingsBoxValue(box, "lavaTemplate", lavaTemplate.value);
              setCustomSettingsBoxValue(box, "showQueryOnPage", showQueryOnPage.value);
              var result = yield invokeBlockAction("SaveCustomSettings", {
                box
              });
              if (result.isSuccess) {
                isModalOpen.value = false;
                reloadBlock();
              } else {
                alert(result.errorMessage || "Unable to save block settings.");
              }
            });
            return _onSave.apply(this, arguments);
          }
          provideSecurityGrant(securityGrant);
          watch(isModalOpen, () => {
            if (!isModalOpen.value) {
              emit("close");
            }
          });
          startLoading();
          return (_ctx, _cache) => {
            return openBlock(), createBlock(unref(Modal), {
              modelValue: isModalOpen.value,
              "onUpdate:modelValue": _cache[9] || (_cache[9] = $event => isModalOpen.value = $event),
              title: "Log Query Settings",
              saveText: saveButtonText.value,
              onSave: onSave
            }, {
              default: withCtx(() => [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
                key: 0,
                alertType: unref(AlertType).Warning
              }, {
                default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
                _: 1
              }, 8, ["alertType"])) : isLoading.value ? (openBlock(), createBlock(unref(LoadingIndicator), {
                key: 1,
                delay: 500
              })) : (openBlock(), createElementBlock(Fragment, {
                key: 2
              }, [createVNode(unref(SectionHeader), {
                title: "Query Setup",
                description: "Write a DuckDB query against the IIS log parquet files. Use [[logs]] as the parquet source placeholder."
              }), createVNode(unref(CodeEditor), {
                modelValue: query.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => query.value = $event),
                label: "Default SQL Query",
                help: "Use [[logs]] in the FROM clause. Example: FROM [[logs]]. Use named DuckDB SQL parameters like $ipAddress.",
                mode: "sql"
              }, null, 8, ["modelValue"]), createVNode(unref(TextBox), {
                modelValue: queryParams.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => queryParams.value = $event),
                label: "Query Parameters",
                class: "input-large",
                help: "Specify the parameters required by the query using the format 'param1=value;param2=value'. Parameters matching URL page parameter values will automatically use those values. Use DuckDB named parameters in SQL like $param1."
              }, null, 8, ["modelValue"]), createVNode(unref(SlidingDateRangePicker), {
                modelValue: dateRange.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => dateRange.value = $event),
                label: "Default Date Range",
                help: "Only parquet files whose filename date stamp falls within this range will be included.",
                previewLocation: "Right",
                enabledSlidingDateRangeUnits: enabledSlidingDateRangeUnits
              }, null, 8, ["modelValue"]), createElementVNode("div", _hoisted_1, [createElementVNode("div", _hoisted_2, [createVNode(unref(NumberBox), {
                modelValue: timeout.value,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => timeout.value = $event),
                label: "Timeout Length",
                help: "The amount of time in seconds to allow the query to run before timing out.",
                inputGroupClasses: "input-width-md"
              }, {
                inputGroupAppend: withCtx(() => [_hoisted_3]),
                _: 1
              }, 8, ["modelValue"])]), createElementVNode("div", _hoisted_4, [createVNode(unref(Switch), {
                modelValue: showQueryOnPage.value,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => showQueryOnPage.value = $event),
                text: "Show Query on Page",
                help: "Shows an editable SQL editor and Run button on the page. The user's most recently run query is saved as a block user preference."
              }, null, 8, ["modelValue"])])]), createVNode(unref(SectionHeader), {
                title: "Results Formatting",
                description: "Choose whether the results render as a grid or through a Lava template."
              }), createElementVNode("div", _hoisted_5, [createVNode(unref(ButtonGroup), {
                modelValue: resultsDisplayMode.value,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => resultsDisplayMode.value = $event),
                items: stdDisplayModeItems.value
              }, null, 8, ["modelValue", "items"])]), !isLavaTemplateDisplayMode.value ? (openBlock(), createElementBlock(Fragment, {
                key: 0
              }, [createVNode(unref(SectionHeader), {
                title: "Grid Settings"
              }), createVNode(unref(TextBox), {
                modelValue: gridTitle.value,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = $event => gridTitle.value = $event),
                label: "Grid Title",
                class: "input-large"
              }, null, 8, ["modelValue"]), createVNode(unref(TextBox), {
                modelValue: selectionUrl.value,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = $event => selectionUrl.value = $event),
                label: "Selection URL",
                class: "input-large",
                help: "The URL to redirect individuals to when they click on a row in the grid. Any column's value can be used in the URL by including it in braces. For example: ~/Person/{Id}"
              }, null, 8, ["modelValue"])], 64)) : (openBlock(), createBlock(unref(CodeEditor), {
                key: 1,
                modelValue: lavaTemplate.value,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = $event => lavaTemplate.value = $event),
                label: "Lava Template",
                help: "The template has access to rows and tables.",
                mode: "lava"
              }, null, 8, ["modelValue"]))], 64))]),
              _: 1
            }, 8, ["modelValue", "saveText"]);
          };
        }
      }));

      script.__file = "src/logQueryCustomSettings.obs";

    })
  };
}));
//# sourceMappingURL=logQueryCustomSettings.obs.js.map
