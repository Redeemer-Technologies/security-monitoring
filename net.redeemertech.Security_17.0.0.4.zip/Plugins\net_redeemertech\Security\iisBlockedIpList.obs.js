System.register(['vue', '@Obsidian/Controls/grid', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Enums/Controls/alertType', '@Obsidian/Utility/block'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, openBlock, createElementBlock, createBlock, unref, withCtx, createTextVNode, toDisplayString, createVNode, createCommentVNode, Grid, TextColumn, textValueFilter, DeleteColumn, NotificationBox, AlertType, useConfigurationValues, useInvokeBlockAction, useReloadBlock;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createBlock = module.createBlock;
      unref = module.unref;
      withCtx = module.withCtx;
      createTextVNode = module.createTextVNode;
      toDisplayString = module.toDisplayString;
      createVNode = module.createVNode;
      createCommentVNode = module.createCommentVNode;
    }, function (module) {
      Grid = module["default"];
      TextColumn = module.TextColumn;
      textValueFilter = module.textValueFilter;
      DeleteColumn = module.DeleteColumn;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      AlertType = module.AlertType;
    }, function (module) {
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      useReloadBlock = module.useReloadBlock;
    }],
    execute: (function () {

      function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          Promise.resolve(value).then(_next, _throw);
        }
      }
      function _asyncToGenerator(fn) {
        return function () {
          var self = this,
            args = arguments;
          return new Promise(function (resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
              asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
          });
        };
      }

      var script = exports('default', defineComponent({
        __name: 'iisBlockedIpList',
        setup(__props) {
          var _config$blockedIps, _config$errorMessage;
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          var reloadBlock = useReloadBlock();
          var blockedIps = ref((_config$blockedIps = config.blockedIps) !== null && _config$blockedIps !== void 0 ? _config$blockedIps : []);
          var errorMessage = ref((_config$errorMessage = config.errorMessage) !== null && _config$errorMessage !== void 0 ? _config$errorMessage : "");
          var isEditable = config.isEditable;
          var gridDataSource = computed(() => Promise.resolve({
            rows: blockedIps.value
          }));
          function goToHistory(idKey) {
            var blockedIp = blockedIps.value.find(b => b.idKey === idKey);
            if (blockedIp !== null && blockedIp !== void 0 && blockedIp.historyIdKey && config.historyDetailPageUrl) {
              window.location.href = config.historyDetailPageUrl.replace("((IdKey))", encodeURIComponent(blockedIp.historyIdKey));
            }
          }
          function unblockIp(_x) {
            return _unblockIp.apply(this, arguments);
          }
          function _unblockIp() {
            _unblockIp = _asyncToGenerator(function* (idKey) {
              var blockedIp = blockedIps.value.find(b => b.idKey === idKey);
              if (!idKey || !confirm("Unblock ".concat((blockedIp === null || blockedIp === void 0 ? void 0 : blockedIp.ipAddress) || "this IP address", "?"))) {
                return;
              }
              var result = yield invokeBlockAction("UnblockIp", {
                idKey
              });
              if (result.isSuccess) {
                reloadBlock();
              } else {
                errorMessage.value = result.errorMessage || "Unable to unblock IP address.";
              }
            });
            return _unblockIp.apply(this, arguments);
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("div", null, [errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: unref(AlertType).Warning
            }, {
              default: withCtx(() => [createTextVNode(toDisplayString(errorMessage.value), 1)]),
              _: 1
            }, 8, ["alertType"])) : (openBlock(), createBlock(unref(Grid), {
              key: 1,
              title: "IIS Blocked IPs",
              data: gridDataSource.value,
              keyField: "idKey",
              itemTerm: "Blocked IP",
              tooltipField: "ipAddress",
              stickyHeader: "",
              onSelectItem: goToHistory
            }, {
              default: withCtx(() => [createVNode(unref(TextColumn), {
                name: "ipAddress",
                title: "IP Address",
                field: "ipAddress",
                filter: unref(textValueFilter),
                width: "25%"
              }, null, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "alertName",
                title: "Alert",
                field: "alertName",
                filter: unref(textValueFilter),
                visiblePriority: "sm",
                width: "25%"
              }, null, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "blockedDateTime",
                title: "Blocked",
                field: "blockedDateTime",
                filter: unref(textValueFilter),
                visiblePriority: "sm",
                width: "15%"
              }, null, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "expiresDateTime",
                title: "Expires",
                field: "expiresDateTime",
                filter: unref(textValueFilter),
                visiblePriority: "xs",
                width: "15%"
              }, null, 8, ["filter"]), createVNode(unref(TextColumn), {
                name: "status",
                title: "Status",
                field: "status",
                filter: unref(textValueFilter),
                visiblePriority: "xs",
                width: "10%"
              }, null, 8, ["filter"]), unref(isEditable) ? (openBlock(), createBlock(unref(DeleteColumn), {
                key: 0,
                title: "Unblock",
                onClick: unblockIp
              })) : createCommentVNode("v-if", true)]),
              _: 1
            }, 8, ["data"]))]);
          };
        }
      }));

      script.__file = "src/iisBlockedIpList.obs";

    })
  };
}));
//# sourceMappingURL=iisBlockedIpList.obs.js.map
